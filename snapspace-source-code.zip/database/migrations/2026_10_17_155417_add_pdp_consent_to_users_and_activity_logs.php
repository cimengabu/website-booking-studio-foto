<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::table('users', function (Blueprint $table) {
            $table->timestamp('privacy_consent_at')->nullable()->after('remember_token');
            $table->string('privacy_consent_ip', 45)->nullable()->after('privacy_consent_at');
        });

        Schema::table('activity_logs', function (Blueprint $table) {
            $table->text('user_agent')->nullable()->after('ip_address');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('users', function (Blueprint $table) {
            $table->dropColumn(['privacy_consent_at', 'privacy_consent_ip']);
        });

        Schema::table('activity_logs', function (Blueprint $table) {
            $table->dropColumn(['user_agent']);
        });
    }
};
