<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\ActivityLog;
use App\Models\Booking;
use App\Models\PhotoDelivery;
use App\Models\PhotoResult;
use App\Services\NotificationService;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Storage;

class AdminPhotoController extends Controller
{
    public function index()
    {
        $user = Auth::user();
        $query = Booking::with(['user', 'room', 'package', 'photoResults', 'photoDelivery', 'photographer'])
            ->whereIn('status', ['confirmed', 'paid', 'dp_paid', 'checked_in', 'in_progress', 'completed', 'delivered', 'closed']);

        if ($user && $user->isPhotographer()) {
            $query->where(function ($q) use ($user) {
                $q->where('photographer_id', $user->id)
                    ->orWhereNull('photographer_id');
            });
        }

        $bookings = $query->latest()->paginate(15);

        return view('admin.photos.index', compact('bookings'));
    }

    public function showUpload(int $bookingId)
    {
        $booking = Booking::with(['user', 'room', 'package', 'photoResults', 'photoDelivery'])->findOrFail($bookingId);

        return view('admin.photos.upload', compact('booking'));
    }

    public function storeUpload(Request $request, int $bookingId)
    {
        $booking = Booking::findOrFail($bookingId);

        $request->validate([
            'photos' => 'nullable|array|max:50', // max 50 photos per batch
            'photos.*' => 'image|mimes:jpeg,jpg,png,webp|max:25600', // up to 25MB each
            'image_urls' => 'nullable|array',
        ], [
            'photos.*.image' => 'Setiap file harus berupa gambar yang valid.',
            'photos.*.mimes' => 'Format file yang didukung: JPEG, JPG, PNG, WEBP.',
            'photos.*.max' => 'Ukuran maksimal per foto adalah 25MB. Silakan kompresi foto terlebih dahulu.',
            'photos.max' => 'Maksimal 50 foto dalam sekali unggah. Silakan unggah bertahap jika lebih.',
        ]);

        $hasUrls = ! empty(array_filter($request->input('image_urls', [])));
        if (! $request->hasFile('photos') && ! $hasUrls) {
            return back()->withErrors(['photos' => 'Harap upload minimal 1 file foto atau masukkan 1 URL foto demo.']);
        }

        try {
            if ($request->hasFile('photos')) {
                foreach ($request->file('photos') as $file) {
                    if (! $file->isValid()) {
                        continue;
                    }

                    $originalName = $file->getClientOriginalName();
                    $filename = time().'_'.uniqid().'.'.$file->getClientOriginalExtension();
                    $path = $file->storeAs("photo_results/{$booking->booking_code}", $filename, 'public');

                    PhotoResult::create([
                        'booking_id' => $booking->id,
                        'path' => $path,
                        'thumb_path' => $path,
                        'original_name' => $originalName,
                        'size' => $file->getSize(),
                    ]);
                }
            }
        } catch (\Throwable $e) {
            return back()->withErrors(['photos' => 'Gagal memproses unggahan file foto: '.$e->getMessage().'. Periksa ukuran file dan koneksi Anda.']);
        }

        // Demo URLs support (if provided via form)
        if ($request->filled('image_urls')) {
            foreach ($request->image_urls as $url) {
                if ($url) {
                    PhotoResult::create([
                        'booking_id' => $booking->id,
                        'path' => $url,
                        'thumb_path' => $url,
                        'original_name' => 'SnapSpace-Edited-'.rand(1000, 9999).'.jpg',
                        'size' => 2450000,
                    ]);
                }
            }
        }

        // Update / Create Photo Delivery Status
        $expiresDays = (int) $request->input('expires_days', 30);
        $expiresAt = $expiresDays > 0 ? now()->addDays($expiresDays) : null;

        PhotoDelivery::updateOrCreate(
            ['booking_id' => $booking->id],
            [
                'delivered_at' => now(),
                'expires_at' => $expiresAt,
                'watermark_enabled' => $request->boolean('watermark_enabled', true),
                'watermark_text' => $request->input('watermark_text', 'SNAPSPACE STUDIO PREVIEW'),
            ]
        );

        $booking->update(['status' => 'delivered']);

        ActivityLog::record(request()->user()?->id, 'admin_upload_photos', "Mengunggah hasil foto untuk booking {$booking->booking_code} (Link aktif {$expiresDays} hari)");

        if ($request->boolean('send_notification', true)) {
            app(NotificationService::class)->sendPhotosReadyNotification($booking);
        }

        return redirect()->route('admin.photos.upload', $booking->id)
            ->with('success', 'Hasil foto berhasil diunggah! Link unduh aktif hingga '.($expiresAt ? $expiresAt->format('d M Y') : 'Selamanya').' & notifikasi disiapkan.');
    }

    public function destroyPhoto(int $photoId)
    {
        $photo = PhotoResult::findOrFail($photoId);
        $bookingId = $photo->booking_id;

        if (Storage::disk('public')->exists($photo->path)) {
            Storage::disk('public')->delete($photo->path);
        }

        $photo->delete();

        return redirect()->route('admin.photos.upload', $bookingId)
            ->with('success', 'Foto berhasil dihapus.');
    }
}
